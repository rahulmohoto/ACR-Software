package com.IDP.Group1.acr;

public class Conversation {
	String[] chat;
	boolean[] isSent;

	Conversation() {
		chat = new String[1000];
		isSent = new boolean[1000];
	}
}
